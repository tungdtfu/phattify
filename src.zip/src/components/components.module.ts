import { NgModule } from '@angular/core';
import { HeaderComponent } from './header/header';
@NgModule({
	declarations: [
		HeaderComponent
	],
	imports: [],
	exports: [
		HeaderComponent
	]
})
export class ComponentsModule {}
