import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DlsclaimerPage } from './dlsclaimer';

@NgModule({
  declarations: [
    DlsclaimerPage,
  ],
  imports: [
    IonicPageModule.forChild(DlsclaimerPage),
  ],
})
export class DlsclaimerPageModule {}
