export const ResponseStatus = {
    success: 'success',
    error: 'error'
}