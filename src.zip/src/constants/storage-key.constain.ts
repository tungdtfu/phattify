export const StorageKey = {
    loginToken: 'loginToken',
    userDetails: 'userDetails'
}